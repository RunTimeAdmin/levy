// Evidence probes for reports-api. Run with: node --experimental-sqlite probe-api.js <crash|nonce>
'use strict';
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const net = require('node:net');
const { ethers } = require(path.join(__dirname, '..', 'reports-api', 'node_modules', 'ethers'));
const { buildServer } = require(path.join(__dirname, '..', 'reports-api', 'dist', 'server.js'));
const { loadConfig } = require(path.join(__dirname, '..', 'reports-api', 'dist', 'config.js'));

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tt-api-'));
const config = loadConfig({ DB_PATH: path.join(dir, 'ledger.db'), NODE_ENV: 'test' });
const { server, close } = buildServer(config);

server.listen(0, async () => {
  const { port } = server.address();
  const mode = process.argv[2];

  if (mode === 'crash') {
    // One raw request with a Host header that `new URL()` rejects. The URL is built outside the try block.
    const sock = net.connect(port, '127.0.0.1', () => {
      sock.write('GET /health HTTP/1.1\r\nHost: bad host\r\nConnection: close\r\n\r\n');
    });
    sock.on('data', (d) => console.log('response:', d.toString().split('\r\n')[0]));
    sock.on('close', () => setTimeout(() => { console.log('server still alive after bad Host header'); close(); }, 300));
    return;
  }

  if (mode === 'nonce') {
    const base = `http://127.0.0.1:${port}`;
    const victim = ethers.Wallet.createRandom();
    // Victim asks for a challenge and starts signing it in their wallet...
    const { message } = await (await fetch(`${base}/auth/nonce?address=${victim.address}`)).json();
    // ...meanwhile an unauthenticated attacker requests a challenge for the SAME address.
    await fetch(`${base}/auth/nonce?address=${victim.address}`);
    const signature = await victim.signMessage(message);
    const res = await fetch(`${base}/auth/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ address: victim.address, signature }),
    });
    console.log('victim verify after attacker re-issued nonce:', res.status, JSON.stringify(await res.json()));
    close();
  }
});
