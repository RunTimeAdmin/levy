// Evidence probes for the review. Run with: node --experimental-sqlite probe-reports.js
'use strict';
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const R = require(path.join(__dirname, '..', 'reports', 'dist', 'index.js'));

const out = (label, value) => console.log(`${label.padEnd(58)} ${value}`);
const throws = (fn) => { try { fn(); return 'THROWS (blocked)'; } catch { return 'THROWS (blocked)'; } };
const passes = (fn) => { try { fn(); return 'passes (NOT blocked)'; } catch { return 'THROWS (blocked)'; } };

console.log('--- 1. Control-plane SQL guards (denylist drift) ---');
for (const sql of [
  "UPDATE tenant_api_keys SET status = 'active'",
  'DELETE FROM tenant_usage_events',
  'DELETE FROM declared_basis',
  'DELETE FROM report_tenant_variants',
  'DELETE FROM processed_logs',
  'UPDATE indexer_checkpoints SET last_block = 0',
  'DELETE FROM tax_lots', // control: listed, should block
]) {
  out(`membership guard: ${sql}`, passes(() => R.assertControlPlaneOnly(sql)));
}
for (const sql of ["UPDATE tenant_api_keys SET status = 'active'", 'DELETE FROM processed_logs']) {
  out(`declared-basis guard: ${sql}`, passes(() => R.assertDeclaredBasisOnly(sql)));
}

console.log('\n--- 2. Holding period (IRS: sold ON the anniversary = short-term) ---');
const ts = (iso) => Math.floor(Date.parse(iso) / 1000);
function rowFor(acq, sold, pnl = '-1000000000000000000', lot = 1) {
  return {
    chain_id: 4663, tx_hash: '0x' + '11'.repeat(32), log_index: 0, chain_lot_id: lot,
    user_address: '0x' + 'aa'.repeat(20), token_address: '0x' + 'bb'.repeat(20),
    amount_sold: '100', proceeds: '0', cost_basis_used: '1000000000000000000', realized_pnl: pnl,
    method: 'FIFO', acquired_at: ts(acq), attested: 1, block_number: 1, block_timestamp: ts(sold),
  };
}
for (const [acq, sold] of [
  ['2024-02-05T00:00:00Z', '2025-02-05T00:00:00Z'], // Pub. 550 example, leap span
  ['2025-01-15T10:00:00Z', '2026-01-15T11:00:00Z'], // non-leap, later time of day
  ['2025-01-15T10:00:00Z', '2026-01-16T00:00:00Z'], // day after anniversary: truly long-term
]) {
  const gen = new R.ReportGenerator({ getUserDispositions: () => [rowFor(acq, sold)] });
  const r = gen.generate(4663, '0x' + 'aa'.repeat(20), Number(sold.slice(0, 4)));
  out(`acq ${acq.slice(0, 10)} sold ${sold.slice(0, 16)}`, r.rows[0].isShortTerm ? 'SHORT-term' : 'LONG-term');
}

console.log('\n--- 3. Wash-sale window (IRS counts calendar days) ---');
{
  const sale = rowFor('2025-01-01T00:00:00Z', '2025-03-01T12:00:00Z');
  for (const buy of ['2025-03-31T11:00:00Z', '2025-03-31T18:00:00Z']) {
    const acqs = [{ token_address: sale.token_address, acquired_at: ts(buy), amount: '100', chain_lot_id: 2 }];
    const [d] = R.washSaleDisallowedByDisposition([sale], acqs, (t) => t.toLowerCase());
    out(`sale 03-01 12:00, replacement ${buy.slice(5, 16)} (day +30)`, d > 0n ? 'wash sale' : 'NOT a wash sale');
  }
}

console.log('\n--- 4. classOf / getAssetClass calls per report ---');
{
  const D = 200, A = 200;
  let calls = 0;
  const disps = Array.from({ length: D }, (_, i) => ({ ...rowFor('2025-01-01T00:00:00Z', '2025-06-01T00:00:00Z'), chain_lot_id: i, log_index: i }));
  // Acquisitions far outside the window so none is consumed: every pair is evaluated.
  const acqs = Array.from({ length: A }, (_, i) => ({ token_address: disps[0].token_address, acquired_at: ts('2020-01-01T00:00:00Z') + i, amount: '1', chain_lot_id: 10_000 + i }));
  const src = {
    getUserDispositions: () => disps,
    getUserAcquisitions: () => acqs,
    getAssetClass: () => { calls++; return undefined; },
  };
  new R.ReportGenerator(src).generate(4663, disps[0].user_address, 2025);
  out(`dispositions=${D}, acquisitions=${A}: getAssetClass() calls`, calls);
}

console.log('\n--- 5. persistReport keeps anchored=1 after the root changes ---');
{
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'tt-')), 'ledger.db');
  const { DatabaseSync } = require('node:sqlite');
  const raw = new DatabaseSync(file);
  raw.exec(`CREATE TABLE reports (report_id TEXT NOT NULL, chain_id INTEGER NOT NULL, user_address TEXT NOT NULL,
    tax_year INTEGER NOT NULL, merkle_root TEXT NOT NULL, report_type TEXT NOT NULL, file_path TEXT,
    anchored INTEGER NOT NULL DEFAULT 0, anchor_tx_hash TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (report_id));`);
  raw.close();
  const db = new R.ReportDatabase(file);
  const base = { reportId: '0x01', chainId: 4663, userAddress: '0xAA', taxYear: 2025, reportType: 'IRS_8949', filePath: null };
  db.persistReport({ ...base, merkleRoot: '0xROOT_A' });
  db.markAnchored('0x01', '0xTX_A');
  db.persistReport({ ...base, merkleRoot: '0xROOT_B' }); // regenerated after a data change
  db.close();
  const check = new DatabaseSync(file);
  const row = check.prepare('SELECT merkle_root, anchored, anchor_tx_hash FROM reports').get();
  check.close();
  out('row after re-persist', JSON.stringify(row));
}
