// Experiments against compiled bot (scratchpad copy). Run with: node --experimental-sqlite exp1.js <botDistTestDir>
const path = require('path');
const D = process.argv[2];
const { ethers } = require(path.join(D, '..', 'node_modules', 'ethers'));
const { Indexer } = require(path.join(D, 'src/indexer'));
const db_ = require(path.join(D, 'src/db'));
const { GenericChainSource } = require(path.join(D, 'src/chain/genericSource'));
const { LotMatcher } = require(path.join(D, 'src/ingestion/matcher'));
const { HistoricalPriceBisector, packRoundId } = require(path.join(D, 'src/pricing/ethersPriceSource'));

const CHAIN = 31337;
const A = '0x00000000000000000000000000000000000000a1';
const B = '0x00000000000000000000000000000000000000b1';
const POOL = '0x00000000000000000000000000000000000000f2';
const R = '0x0000000000000000000000000000000000000010';
const U = '0x0000000000000000000000000000000000000020';
const TT = ethers.id('Transfer(address,address,uint256)');
const tl = (token, from, to, value, block, tx, idx, bh) => ({ address: token, topics: [TT, ethers.zeroPadValue(from, 32), ethers.zeroPadValue(to, 32)], data: ethers.toBeHex(value, 32), blockNumber: block, blockHash: bh, transactionHash: tx, index: idx });

class FakeProvider {
  constructor(logs) { this.logs = logs; this.blocks = new Map(); this.head = 0; this.getBlockCalls = 0; }
  seed(n, salt = 'a') { for (let i = 1; i <= n; i++) this.blocks.set(i, { hash: '0x' + salt.repeat(63) + i.toString(16), timestamp: 1_700_000_000 + i * 12 }); this.head = n; }
  async getNetwork() { return { chainId: CHAIN }; }
  async getBlockNumber() { return this.head; }
  async getBlock(n) { this.getBlockCalls++; const b = this.blocks.get(n); return b ? { ...b } : null; }
  async getLogs(f) { return this.logs.filter((l) => l.blockNumber >= f.fromBlock && l.blockNumber <= f.toBlock && (!f.topics || l.topics[0] === f.topics[0]) && (!f.address || [].concat(f.address).map(x=>x.toLowerCase()).includes(l.address.toLowerCase()))); }
}
const inference = { priceSource: { async roundAt() { return { answer: 1_00000000n, updatedAt: 1_700_000_000 }; } }, feedFor: (t) => t.toLowerCase() === R ? { feedDecimals: 8 } : null, toleranceBps: 100 };
function repos(db) {
  const r = { db, checkpoints: new db_.CheckpointRepo(db), processed: new db_.ProcessedLogRepo(db), lots: new db_.LotRepo(db), dispositions: new db_.DispositionRepo(db), harvests: new db_.HarvestRepo(db), anchors: new db_.ReportAnchorRepo(db), washSale: new db_.WashSaleRepo(db), assetClasses: new db_.AssetClassRepo(db), pending: new db_.PendingDispositionRepo(db) };
  r.matcher = new LotMatcher(r.lots, r.pending, r.dispositions, 'FIFO', new db_.AssertionRepo(db));
  return r;
}
const CFG = { startBlock: 1, confirmations: 2, maxRange: 2000, reorgDepth: 5, idleDelayMs: 0, stream: 'generic' };

(async () => {
  // E1: reorg detection with the real GenericChainSource (hashCache).
  {
    const p = new FakeProvider([]); p.seed(20);
    const db = new db_.Database(':memory:');
    const src = new GenericChainSource({ provider: p, registry: [{ address: R, decimals: 18, isQuoteStable: false }], wallets: [A], inference });
    const ix = new Indexer(src, repos(db), CFG);
    const r1 = await ix.runOnce();
    p.seed(20, 'b'); // every block hash changes (deep reorg)
    p.head = 21; p.blocks.set(21, { hash: '0x' + 'b'.repeat(64), timestamp: 1_700_000_000 + 21*12 });
    const r2 = await ix.runOnce();
    const src2 = new GenericChainSource({ provider: p, registry: [{ address: R, decimals: 18, isQuoteStable: false }], wallets: [A], inference });
    const r3 = await new Indexer(src2, repos(db), CFG).runOnce();
    console.log('E1 first:', JSON.stringify(r1), '| same-process after reorg:', JSON.stringify(r2), '| fresh source (restart):', JSON.stringify(r3));
  }
  // E2: transfer between two in-scope wallets A -> B (same tx/log identity for both sides).
  {
    const p = new FakeProvider([]); p.seed(20);
    const h = (n) => p.blocks.get(n).hash;
    p.logs = [
      tl(U, A, POOL, 100n * 10n**6n, 3, '0x' + '11'.repeat(32), 0, h(3)),
      tl(R, POOL, A, 100n * 10n**18n, 3, '0x' + '11'.repeat(32), 1, h(3)),
      tl(R, A, B, 40n * 10n**18n, 8, '0x' + '22'.repeat(32), 0, h(8)), // A gives 40 to B
    ];
    const db = new db_.Database(':memory:');
    const src = new GenericChainSource({ provider: p, registry: [{ address: R, decimals: 18, isQuoteStable: false }, { address: U, decimals: 6, isQuoteStable: true }], wallets: [A, B], inference });
    const logs = await src.getLogs(1, 18);
    await new Indexer(src, repos(db), CFG).runOnce();
    console.log('E2 source emitted for tx 0x22..:', logs.filter(l => l.txHash.startsWith('0x22')).map(l => `${l.eventName}(${l.args.user.slice(-2)})@${l.logIndex}`).join(', '));
    console.log('E2 B lots:', db.all('SELECT COUNT(*) n FROM tax_lots WHERE user_address=?', [B])[0].n, ' A pending sells:', db.all('SELECT COUNT(*) n FROM pending_dispositions WHERE user_address=?', [A])[0].n);
  }
  // E3: self-transfer A -> A.
  {
    const p = new FakeProvider([]); p.seed(20);
    const h = (n) => p.blocks.get(n).hash;
    p.logs = [
      tl(U, A, POOL, 100n * 10n**6n, 3, '0x' + '11'.repeat(32), 0, h(3)),
      tl(R, POOL, A, 100n * 10n**18n, 3, '0x' + '11'.repeat(32), 1, h(3)),
      tl(R, A, A, 100n * 10n**18n, 8, '0x' + '33'.repeat(32), 0, h(8)),
    ];
    const db = new db_.Database(':memory:');
    const src = new GenericChainSource({ provider: p, registry: [{ address: R, decimals: 18, isQuoteStable: false }, { address: U, decimals: 6, isQuoteStable: true }], wallets: [A], inference });
    await new Indexer(src, repos(db), CFG).runOnce();
    const lots = new db_.LotRepo(db).getOpenLots(CHAIN, A, R);
    console.log('E3 self-transfer: open lots for A =', lots.length, 'total units =', lots.reduce((s, l) => s + BigInt(l.amount), 0n) / 10n**18n, '(true holding: 100)');
  }
  // E4: assertion edited AFTER promotion, then another sell for the pair re-runs promotePair.
  {
    const db = new db_.Database(':memory:');
    const r = repos(db);
    const lot = (id, amt, blk) => r.lots.upsertLot({ chain_id: CHAIN, user_address: A, chain_lot_id: id, token_address: R, amount: String(amt), cost_basis: String(amt), acquired_at: 1000 + blk, disposed: 0, attested: 1, basis_confidence: 'INFERRED_SWAP', block_number: blk, tx_hash: '0x' + String(blk).padStart(64, '0'), log_index: 0 }, 'generic');
    lot(1, 200, 1); lot(2, 100, 2);
    const sell = (tx, blk, amt, proceeds) => r.pending.insert({ chain_id: CHAIN, tx_hash: tx, log_index: 0, user_address: A, token_address: R, amount_sold: String(amt), proceeds: String(proceeds), proceeds_confidence: 'INFERRED_SWAP', block_number: blk, block_timestamp: 5000 + blk }, 'generic');
    const S1 = '0x' + 'cc'.repeat(32);
    sell(S1, 10, 150, 300);
    r.matcher.promotePair(CHAIN, A, R, 'generic');
    new db_.AssertionRepo(db).set(CHAIN, A, R, S1, 0, [2, 1]); // user "corrects" to SpecID [lot2, lot1]
    sell('0x' + 'dd'.repeat(32), 20, 1, 1); // later unrelated sell triggers re-promotion of the pair
    r.matcher.promotePair(CHAIN, A, R, 'generic');
    const rows = db.all('SELECT chain_lot_id, amount_sold, proceeds, method FROM dispositions WHERE tx_hash=? ORDER BY log_index', [S1]);
    const sold = rows.reduce((s, x) => s + BigInt(x.amount_sold), 0n), proc = rows.reduce((s, x) => s + BigInt(x.proceeds), 0n);
    console.log('E4 rows for S1:', JSON.stringify(rows), `sum amount_sold=${sold} (sell was 150), sum proceeds=${proc} (sell was 300)`);
  }
  // E5: bisector with a transient RPC failure mid-search.
  {
    const rounds = []; for (let i = 1; i <= 100; i++) rounds.push({ roundId: packRoundId(1n, BigInt(i)), answer: BigInt(i) * 10n**8n, updatedAt: BigInt(1000 + i * 100) });
    let failOnce = true;
    const reader = (flaky) => ({
      async latestRoundData() { return rounds[99]; },
      async getRoundData(id) { const i = Number(id & ((1n << 64n) - 1n)); if (flaky && failOnce && i === 50) { failOnce = false; throw new Error('429 Too Many Requests'); } return rounds[i - 1]; },
      async phaseAggregatorLatestRound() { return null; },
    });
    const T = 1000 + 75 * 100 + 50; // correct answer = round 75
    const good = await new HistoricalPriceBisector(() => reader(false)).roundAt(R, T);
    const bad = await new HistoricalPriceBisector(() => reader(true)).roundAt(R, T);
    console.log('E5 correct round answer =', good.answer / 10n**8n, '| with one transient RPC error =', bad.answer / 10n**8n, 'updatedAt', bad.updatedAt, 'vs', good.updatedAt);
  }
})().catch((e) => { console.error(e); process.exit(1); });
