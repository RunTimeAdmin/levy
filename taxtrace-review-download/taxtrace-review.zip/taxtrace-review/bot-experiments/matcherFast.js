// Prototype of a drop-in matchDispositions with identical output: binary-search the eligible prefix and
// keep an amortized FIFO head pointer instead of pool.filter() per sell.
const path = require('path');
const orig = require(path.join(process.argv[2], 'src/ingestion/matcher'));
const { ALLOC_STRIDE, UNCOVERED_LOT_ID, minConfidence } = orig;
const cmp = (a, b) => a.blockNumber - b.blockNumber || a.logIndex - b.logIndex || (a.txHash < b.txHash ? -1 : a.txHash > b.txHash ? 1 : 0);
function fast(lots, sells) {
  const pool = [...lots].sort(cmp).map((l, idx) => ({ ...l, idx }));
  const byId = new Map(); for (const p of pool) byId.set(p.chainLotId, p);
  let head = 0; const out = [];
  for (const sell of sells) {
    const amount = sell.amountSold, proceeds = sell.proceeds; let remaining = amount;
    let lo = 0, hi = pool.length; while (lo < hi) { const m = (lo + hi) >> 1; if (cmp(pool[m], sell) < 0) lo = m + 1; else hi = m; }
    const k = lo; // eligible = pool[0..k)
    const useSpec = sell.lotSelection !== undefined && sell.lotSelection.length > 0;
    const rows = []; let alloc = 0, conf = null, oversold = false;
    const consume = (lot) => {
      const take = remaining > lot.amount ? lot.amount : remaining;
      const costShare = (lot.costBasis * take) / lot.amount, proceedsShare = (proceeds * take) / amount;
      rows.push({ chainLotId: lot.chainLotId, amountSold: take, proceeds: proceedsShare, costBasisUsed: costShare, realizedPnl: proceedsShare - costShare, acquiredAt: lot.acquiredAt, lotConfidence: lot.basisConfidence, logIndex: sell.logIndex * ALLOC_STRIDE + alloc });
      alloc++; lot.amount -= take; lot.costBasis -= costShare; conf = conf === null ? lot.basisConfidence : minConfidence(conf, lot.basisConfidence); remaining -= take;
    };
    if (useSpec) {
      for (const id of sell.lotSelection) { if (remaining === 0n) break; const p = byId.get(id); if (!p || p.idx >= k || p.amount === 0n) continue; consume(p); }
    } else {
      while (head < pool.length && pool[head].amount === 0n) head++;
      for (let j = head; j < k && remaining > 0n; j++) { if (pool[j].amount === 0n) continue; consume(pool[j]); }
    }
    if (remaining > 0n) { oversold = true; const take = remaining, ps = (proceeds * take) / amount; rows.push({ chainLotId: UNCOVERED_LOT_ID, amountSold: take, proceeds: ps, costBasisUsed: 0n, realizedPnl: ps, acquiredAt: null, lotConfidence: 'UNKNOWN', logIndex: sell.logIndex * ALLOC_STRIDE + alloc }); alloc++; conf = conf === null ? 'UNKNOWN' : minConfidence(conf, 'UNKNOWN'); remaining = 0n; }
    out.push({ sell, rows, matchedConfidence: conf ?? 'UNKNOWN', oversold, method: useSpec ? 'SPEC_ID' : 'FIFO' });
  }
  return out;
}
// Fuzz: random interleavings, SpecID selections (incl. invalid/future ids), duplicate ids in a selection.
let seed = 42; const rnd = (n) => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed % n; };
const confs = ['ATTESTED_ORACLE', 'INFERRED_SWAP', 'USER_DECLARED', 'UNKNOWN'];
const ser = (x) => JSON.stringify(x, (k, v) => typeof v === 'bigint' ? v.toString() + 'n' : v);
let cases = 0;
for (let c = 0; c < 3000; c++) {
  const L = rnd(12), Sn = rnd(10), lots = [], sells = [];
  for (let i = 0; i < L; i++) lots.push({ chainLotId: 100 + i, amount: BigInt(1 + rnd(50)), costBasis: BigInt(rnd(1000)), acquiredAt: rnd(100), basisConfidence: confs[rnd(4)], blockNumber: rnd(20), logIndex: rnd(3), txHash: '0x' + rnd(4) });
  for (let i = 0; i < Sn; i++) { const sel = rnd(3) === 0 ? Array.from({ length: rnd(4) }, () => 100 + rnd(L + 2)) : undefined; sells.push({ txHash: '0xs' + i, logIndex: rnd(3), blockNumber: rnd(20), blockTimestamp: 0, amountSold: BigInt(1 + rnd(60)), proceeds: BigInt(rnd(500)), lotSelection: sel }); }
  sells.sort(cmp);
  const a = ser(orig.matchDispositions(lots, sells)), b = ser(fast(lots, sells));
  if (a !== b) { console.log('MISMATCH case', c); console.log(a); console.log(b); process.exit(1); }
  cases++;
}
console.log('fuzz: identical output on', cases, 'random cases');
for (const n of [4000, 8000]) {
  const lots = [], sells = [];
  for (let i = 0; i < n; i++) { lots.push({ chainLotId: i, amount: 100n, costBasis: 100n, acquiredAt: i, basisConfidence: 'INFERRED_SWAP', blockNumber: i * 2, logIndex: 0, txHash: '0x' + i }); sells.push({ txHash: '0xs' + i, logIndex: 1, blockNumber: i * 2 + 1, blockTimestamp: 0, amountSold: 50n, proceeds: 40n }); }
  let t = process.hrtime.bigint(); orig.matchDispositions(lots, sells); const o = Number(process.hrtime.bigint() - t) / 1e6;
  t = process.hrtime.bigint(); fast(lots, sells); const f = Number(process.hrtime.bigint() - t) / 1e6;
  console.log(`L=S=${n}: original ${o.toFixed(0)} ms, prototype ${f.toFixed(0)} ms`);
}
