const path = require('path');
const db_ = require(path.join(process.argv[2], 'src/db'));
const db = new db_.Database(':memory:');
const q = {
  'LotRepo.deleteFromBlock': 'DELETE FROM tax_lots WHERE chain_id = 1 AND block_number >= 5 AND stream = \'main\'',
  'DispositionRepo.deleteFromBlock': 'DELETE FROM dispositions WHERE chain_id = 1 AND block_number >= 5 AND stream = \'main\'',
  'HarvestRepo.deleteFromBlock': 'DELETE FROM harvest_events WHERE chain_id = 1 AND block_number >= 5 AND stream = \'main\'',
  'LotRepo.soldByLot': "SELECT chain_lot_id, amount_sold FROM dispositions WHERE chain_id = 1 AND user_address = 'a' AND token_address = 't'",
  'LotRepo.soldForLot': "SELECT amount_sold FROM dispositions WHERE chain_id = 1 AND user_address = 'a' AND chain_lot_id = 3",
  'WashSaleRepo.hasEventSince': "SELECT COUNT(*) AS n FROM wash_sale_events WHERE chain_id = 1 AND user_address = 'a' AND asset_class = 'c' AND direction = 'BUY' AND occurred_at >= 5",
  'LotRepo.getLotsForMatching': "SELECT * FROM tax_lots WHERE chain_id = 1 AND user_address = 'a' AND token_address = 't' ORDER BY block_number, log_index, tx_hash",
  'Pending.getForUserToken': "SELECT * FROM pending_dispositions WHERE chain_id = 1 AND user_address = 'a' AND token_address = 't' ORDER BY block_number, log_index, tx_hash",
};
for (const [k, sql] of Object.entries(q)) console.log(k.padEnd(30), '|', db.all('EXPLAIN QUERY PLAN ' + sql).map(r => r.detail).join(' ; '));
