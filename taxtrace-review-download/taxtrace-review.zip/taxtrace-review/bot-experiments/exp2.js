const path = require('path');
const D = process.argv[2];
const { Indexer } = require(path.join(D, 'src/indexer'));
const db_ = require(path.join(D, 'src/db'));
const { GenericChainSource } = require(path.join(D, 'src/chain/genericSource'));
const { EthersChainSource } = require(path.join(D, 'src/chain/source'));
const CHAIN = 31337, A = '0x00000000000000000000000000000000000000a1', R = '0x0000000000000000000000000000000000000010';
class FakeProvider {
  constructor() { this.blocks = new Map(); this.head = 0; }
  seed(n, salt) { for (let i = 1; i <= n; i++) this.blocks.set(i, { hash: '0x' + salt.repeat(63) + i.toString(16), timestamp: 1_700_000_000 + i * 12, number: i }); this.head = n; }
  async getNetwork() { return { chainId: BigInt(CHAIN) }; }
  async getBlockNumber() { return this.head; }
  async getBlock(n) { const b = this.blocks.get(n); return b ? { ...b } : null; }
  async getLogs() { return []; }
}
const inference = { priceSource: { async roundAt() { return null; } }, feedFor: () => null };
const repos = (db) => ({ db, checkpoints: new db_.CheckpointRepo(db), processed: new db_.ProcessedLogRepo(db), lots: new db_.LotRepo(db), dispositions: new db_.DispositionRepo(db), harvests: new db_.HarvestRepo(db), anchors: new db_.ReportAnchorRepo(db), washSale: new db_.WashSaleRepo(db), assetClasses: new db_.AssetClassRepo(db) });
const CFG = { startBlock: 1, confirmations: 2, maxRange: 2000, reorgDepth: 5, idleDelayMs: 0 };
const mkGeneric = (p) => new GenericChainSource({ provider: p, registry: [{ address: R, decimals: 18, isQuoteStable: false }], wallets: [A], inference });
const mkEthers = (p) => new EthersChainSource({ provider: p, harvesterAddress: A, reporterAddress: R });
(async () => {
  for (const [name, mk] of [['GenericChainSource', mkGeneric], ['EthersChainSource', mkEthers]]) {
    const p = new FakeProvider(); p.seed(20, 'a');
    const db = new db_.Database(':memory:');
    const src = mk(p);
    await new Indexer(src, repos(db), CFG).runOnce(); // checkpoint = 18, hash cached
    p.seed(20, 'b'); // reorg rewrites every block
    const sameProc = await new Indexer(src, repos(db), CFG).runOnce();
    const p2 = new FakeProvider(); p2.seed(20, 'a');
    const db2 = new db_.Database(':memory:');
    await new Indexer(mk(p2), repos(db2), CFG).runOnce();
    p2.seed(20, 'b');
    const restarted = await new Indexer(mk(p2), repos(db2), CFG).runOnce();
    console.log(`E1 ${name}: same process reorg=${sameProc && sameProc.reorg} | fresh source reorg=${restarted && restarted.reorg}`);
  }
  // E6: abort-listener accumulation from delay() (index.ts/indexer.ts pattern)
  const ac = new AbortController();
  const warnings = []; process.on('warning', (w) => warnings.push(w.name + ': ' + w.message.slice(0, 90)));
  const delay = (ms, signal) => new Promise((resolve) => { const t = setTimeout(resolve, ms); signal.addEventListener('abort', () => { clearTimeout(t); resolve(); }, { once: true }); });
  for (let i = 0; i < 50; i++) await delay(0, ac.signal);
  const { getEventListeners } = require('events');
  await new Promise((r) => setTimeout(r, 10));
  console.log('E6 abort listeners after 50 delay() calls:', getEventListeners(ac.signal, 'abort').length, '| warnings:', warnings);
})();
