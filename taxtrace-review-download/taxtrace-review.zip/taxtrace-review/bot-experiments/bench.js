const path = require('path');
const D = process.argv[2];
const { matchDispositions } = require(path.join(D, 'src/ingestion/matcher'));
const db_ = require(path.join(D, 'src/db'));
for (const n of [1000, 4000, 8000]) {
  const lots = [], sells = [];
  for (let i = 0; i < n; i++) {
    lots.push({ chainLotId: i, amount: 100n, costBasis: 100n, acquiredAt: i * 2, basisConfidence: 'INFERRED_SWAP', blockNumber: i * 2, logIndex: 0, txHash: '0x' + i.toString(16).padStart(64, '0') });
    sells.push({ txHash: '0x' + (i + 1e6).toString(16).padStart(64, '0'), logIndex: 1, blockNumber: i * 2 + 1, blockTimestamp: i * 2 + 1, amountSold: 50n, proceeds: 40n });
  }
  const t = process.hrtime.bigint(); matchDispositions(lots, sells); const ms = Number(process.hrtime.bigint() - t) / 1e6;
  console.log(`matchDispositions L=S=${n}: ${ms.toFixed(0)} ms`);
}
const db = new db_.Database(':memory:');
const N = 20000;
let t = process.hrtime.bigint();
db.transaction(() => { for (let i = 0; i < N; i++) db.run('INSERT OR IGNORE INTO processed_logs (chain_id, tx_hash, log_index, block_number, block_hash, event_name, stream) VALUES (?,?,?,?,?,?,?)', [1, 'a' + i, 0, i, 'h', 'E', 'main']); });
const viaRun = Number(process.hrtime.bigint() - t) / 1e6;
const stmt = db.raw.prepare('INSERT OR IGNORE INTO processed_logs (chain_id, tx_hash, log_index, block_number, block_hash, event_name, stream) VALUES (?,?,?,?,?,?,?)');
t = process.hrtime.bigint();
db.transaction(() => { for (let i = 0; i < N; i++) stmt.run(1, 'b' + i, 0, i, 'h', 'E', 'main'); });
const viaCached = Number(process.hrtime.bigint() - t) / 1e6;
console.log(`${N} inserts: Database.run (prepare per call) ${viaRun.toFixed(0)} ms vs cached statement ${viaCached.toFixed(0)} ms`);
